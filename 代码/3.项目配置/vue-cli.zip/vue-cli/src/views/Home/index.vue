<template>
  <h1 class="home-title">Home~~~</h1>
</template>

<script>
export default {
  name: "Home",
};
</script>

<style>
.home-title {
  color: deeppink;
  font-size: 30px;
}
</style>
